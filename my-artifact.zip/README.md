This is asset
